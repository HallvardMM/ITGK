#Øving 3 Oppgave 2b)
for t in range(24):
    for m in range(60):
            print(t,":",m)
