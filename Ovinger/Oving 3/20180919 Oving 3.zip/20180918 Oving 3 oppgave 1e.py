#Øving 3 oppgave 1e
for n in range(1,6):
    print(n)
