# Øving 3 Oppgave 2a)
heltall = 0
summen = 0
antall = 0
while antall < 7:
    heltall = int(input("Skriv inn et heltall: "))
    summen += heltall
    antall += 1
print("Summen av tallene ble", summen)
