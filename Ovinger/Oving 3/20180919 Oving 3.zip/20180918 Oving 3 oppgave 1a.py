#Øving 3 oppgave 1a
antall=int(input("Hvor mange adjektiv vil du gi? "))
for i in range(antall):
    adj = input("Beskriv deg selv med et adjektiv? ")
    print("Hah, du", adj + "!? Jeg er mye", adj + "ere!")
print("Takk for nå!")

