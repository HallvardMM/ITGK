# Øving 3 Oppgave 2b)
summen = 1
n=1
while summen < 1000:
    n+=1
    summen *=n 
    print(summen)
