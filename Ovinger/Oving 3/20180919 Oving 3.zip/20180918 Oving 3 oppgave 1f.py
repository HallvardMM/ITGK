#Øving 3 oppgave 1f
for n in range(15,0,-1):
    print(n)
