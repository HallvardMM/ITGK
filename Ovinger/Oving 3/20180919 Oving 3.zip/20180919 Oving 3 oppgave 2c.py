# Øving 3 Oppgave 2c)
forsøk = 0
x=0
while x != "St. Helena":
    x=str(input("Hvor ble Napoléon Bonaparte forvist? "))
    forsøk += 1
print("Korrekt!! Du brukte", forsøk, "forsøk.")
        
