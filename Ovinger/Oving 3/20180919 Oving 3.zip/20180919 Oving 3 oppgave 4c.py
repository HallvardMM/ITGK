#Øving  3 Oppgave 4c)
#printer bare ut "16" fordi den høyer opp i andre til i>10 da printer den i
# utregningen blir 2,4,8,16 som printes ut
i = 1
while i<10:
    i = i*2
print(i)
