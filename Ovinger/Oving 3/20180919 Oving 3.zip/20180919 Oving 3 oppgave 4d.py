#Øving  3 Oppgave 4d)
#i blir 1*2*2*2 som blir 8 som printes ut
#j blir 3-1,2-1,1-1=0; dette skjer tre ganger og er derfor i ganges med 2 tre ganger
i = 1
j = 3
while j>0:
    i = i*2
    j = j - 1
print(i)
