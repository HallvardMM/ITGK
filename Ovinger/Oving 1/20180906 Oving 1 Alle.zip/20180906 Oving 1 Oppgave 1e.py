#Oppgave 1e)
# I oppgave b) printet jeg tall og strings
# I oppgave c) printet jeg " tegnet så jeg måtte bruke ' foran og bak teksten
# print('hei")

