#øving 1 Oppgave 3a)
print(input("Navn? "), "- kult navn!")
print(input("Favorittfag? "), "- interessant!")
