#Oppgave 1a)
print("Jeg elsker ITGK!")
