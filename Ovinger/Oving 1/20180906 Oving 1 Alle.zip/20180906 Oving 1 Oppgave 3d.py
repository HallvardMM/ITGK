#Øving 1 Oppgave 3d
navn4 = "Per"
ideal_alder = 42
kundensAlder = 37
differanse = ideal_alder - kundensAlder
print(navn4, "er", differanse, "år unna idealalderen")
