#Oppgave 1b) Øving 1
print("Norge")
print()
print("Areal (kv.km):", 385180)
print("Folketall (mill.):", 5.3)
