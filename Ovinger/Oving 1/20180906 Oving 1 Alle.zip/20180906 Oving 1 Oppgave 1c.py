# Oppgave 1c)
print('"Jeg elsker ITGK!" ropte studenten da 1c funket.')
