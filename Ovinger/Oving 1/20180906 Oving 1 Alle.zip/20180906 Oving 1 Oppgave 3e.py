#Øving 1 Oppgave 3e
navn = str("Hallvard Molin Morstøl")
alder = int(21)
print("Jeg heter", navn+",","og er", alder, "år.")
