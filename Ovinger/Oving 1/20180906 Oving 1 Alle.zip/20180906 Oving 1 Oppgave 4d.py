#øving 1 Oppgave 4d)
tall = float(input("Skriv et flyttall: "))
desimal = int(input("Hvor mange desimaler er ønskelig? "))
print("Tallet du skrev er "+str(tall)+" og med "+str(desimal)+" desimaler blir det" +str(round(tall,desimal)))
