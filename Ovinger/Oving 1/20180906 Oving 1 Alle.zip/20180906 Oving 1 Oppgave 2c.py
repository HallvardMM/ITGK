#Øving 1 Oppgave 2c
from math import sqrt, pi

# importerer fra math-biblioteket
  
print("|-8|, dvs. absoluttverdien til -8, er", abs(8))
print(2.544, "avrundet til helt tall er", round(2.544))
print("Funksjonen int() derimot bare kutter vekk desimalene:", int(2.544))
print(2.544, "avrundet til to desimaler er", round(2.544,2))
print("Kvadratroten til", 10, "er", sqrt(10))
print("En sirkel med radius 7 har omkrets", 2*pi*7)
print("En sirkel med radius 7 har areal", pi*7**2)
