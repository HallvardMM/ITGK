#Øving 2 oppgave 3a)
# 1, 3, 5
x=3
y=8
z=-3
print(-5<z and 5>z) #true
print(not y==8) #false
print(x==8 or y==8) #true
print(not(x<=3 or y>=9))#false
print((not(x**2 !=8 and y-z == 5) or x+y==y-z))#true
