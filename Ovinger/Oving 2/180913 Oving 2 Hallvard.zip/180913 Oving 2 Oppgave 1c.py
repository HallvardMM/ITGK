#Øving 2 oppgave 1c)
alder = int(input("Skriv inn din alder: "))
if alder >= 18:
    print("Du kan stemme:)")
else:
    print("Du kan ikke stemme ennå") 
