#Øving 2 oppgave 2a)
matvare1=input("Matvare ")
matvare2=input("Matvare ")
if str.lower(matvare1)==str.lower(matvare2):
    print("Sammenligner "+str(matvare1)+" og "+matvare2)
    print("Det er samme matvare")
else:
    print("Dette er to forskjellige matvarer")
    
