#Øving 2 Oppgave 1a)
tid = int(input("Hvor mange minutt har kaken stått i ovnen? "))
if tid >= 50:
    print("Kaken kan tas ut av ovnen.")
print("Tips til servering: vaniljeis.")
