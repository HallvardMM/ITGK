#Øving 5 oppgave 3a

#Kodesnutt 1 cakes vil ikke kjøre pga plassering av cake=1.
#Kodesnutt 2 cakes vil ikke kjøre fordi cupcakes er en lokal variabel
#Kodesnutt 3 cakes vil ikke kjøre fordi cake ikke er definert.
#Kodesnutt 3 vil fortsatt kjøre fordi den ikke kjører cakes().

#Oppgave 3b)

def deling():
    x=float(input("x = "))
    y=float(input("y = "))
    num=x//y
    print("Heltallsdivisjon av",x," over", y," gir ", num)

def gange():
    x=float(input("x = "))
    num=x**2
    print("Kvadratet av", x," er ", num)

deling()
gange()

# Oppgave 3c)

#Nei det kan ikke lage problem i dette tilfelle, men hvis du returner variablen.
#Så vil det være problematisk. For da vil det siste programmet overskrive varianblen til det andre.







